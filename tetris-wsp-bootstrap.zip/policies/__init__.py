"""Placement policies and baselines."""
