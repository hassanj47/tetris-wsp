"""Deterministic simplified Tetris engine."""
